/***********************************

> 應用名稱：BaseVPN
> 軟件版本：1.2.1[非國區商店]
> 下載地址：https://apps.apple.com/tw/app/id1541567902
> 腳本作者：Cuttlefish
> 微信賬號：墨魚手記
> 解鎖說明：一次性解鎖，高速魔法，會員訂閱至2999
> 網球規則：https://share.weiyun.com/wUJijlw9
> 更新時間：2022-03-27
> 通知頻道：https://t.me/ddgksf2021
> 問題反饋：https://t.me/ddgksf2013_bot
> 特別說明：本腳本僅供學習交流使用，禁止轉載售賣
 
[rewrite_local]

# ～ BaseVPN解鎖訂閱（2022-03-27）@ddgksf2013
^https?:\/\/buy\.itunes\.apple\.com\/verifyReceipt$ url script-response-body https://codeberg.org/ddgksf2013/Cuttlefish/raw/branch/master/Crack/basevpnpro.js

[mitm] 

hostname=buy.itunes.apple.com

***********************************/


var _0xody='jsjiami.com.v6',_0xody_=['_0xody'],_0x15b4=[_0xody,'\u672c\u8173\u672c\u50c5\u4f9b\u5b78\u7fd2\u4ea4\u6d41\u4f7f\u7528\uff0c\u7981\u6b62\u8f49\u8f09\u552e\u8ce3','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x2e\x6d\x65\x2f\x64\x64\x67\x6b\x73\x66\x32\x30\x32\x31','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x2e\x6d\x65\x2f\x64\x64\x67\x6b\x73\x66\x32\x30\x31\x33\x5f\x62\x6f\x74','\x50\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e','\x63\x6f\x6d\x2e\x6d\x65\x64\x69\x61\x65\x64\x69\x74\x6f\x72\x2e\x76\x69\x64\x65\x6f','\x34\x33\x37','\x32\x30\x39\x39\x2d\x31\x32\x2d\x33\x31\x20\x30\x30\x3a\x30\x30\x3a\x30\x30\x20\x45\x74\x63\x2f\x47\x4d\x54','\x33\x32\x35\x30\x33\x35\x36\x34\x38\x30\x30\x30\x30\x30','\x32\x30\x39\x39\x2d\x31\x32\x2d\x33\x31\x20\x30\x30\x3a\x30\x30\x3a\x30\x30\x20\x41\x6d\x65\x72\x69\x63\x61\x2f\x4c\x6f\x73\x5f\x41\x6e\x67\x65\x6c\x65\x73','\x32\x30\x32\x30\x2d\x31\x30\x2d\x31\x30\x20\x31\x30\x3a\x31\x30\x3a\x31\x30\x20\x45\x74\x63\x2f\x47\x4d\x54','\x31\x36\x30\x32\x32\x39\x35\x38\x31\x30\x30\x30\x30','\x32\x30\x32\x30\x2d\x31\x30\x2d\x31\x30\x20\x31\x30\x3a\x31\x30\x3a\x31\x30\x20\x41\x6d\x65\x72\x69\x63\x61\x2f\x4c\x6f\x73\x5f\x41\x6e\x67\x65\x6c\x65\x73','\x34\x33\x33','\x79\x65\x61\x72\x61\x75\x74\x6f\x72\x65\x6e\x65\x77','\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38\x38','\x32\x30\x31\x31\x2d\x31\x31\x2d\x31\x31\x20\x31\x31\x3a\x31\x31\x3a\x31\x31\x20\x45\x74\x63\x2f\x47\x4d\x54','\x74\x72\x75\x65','\x66\x61\x6c\x73\x65','\x39\x39\x39\x39\x39\x39\x39\x39','\x73\x74\x72\x69\x6e\x67\x69\x66\x79','\x6a\x73\x4c\x4f\x53\x54\x42\x6b\x6a\x69\x65\x61\x6c\x6d\x69\x6e\x2e\x63\x46\x79\x71\x6f\x55\x5a\x6d\x58\x2e\x76\x36\x3d\x3d'];function _0x26f0(_0x2affeb,_0x3aaa85){_0x2affeb=~~'0x'['concat'](_0x2affeb['slice'](0x0));var _0x191594=_0x15b4[_0x2affeb];return _0x191594;};(function(_0x22fa6d,_0x5a7e44){var _0x36cf9d=0x0;for(_0x5a7e44=_0x22fa6d['shift'](_0x36cf9d>>0x2);_0x5a7e44&&_0x5a7e44!==(_0x22fa6d['pop'](_0x36cf9d>>0x3)+'')['replace'](/[LOSTBkelnFyqUZX=]/g,'');_0x36cf9d++){_0x36cf9d=_0x36cf9d^0xda40b;}}(_0x15b4,_0x26f0));var ddgksf2013={'warning':_0x26f0('0'),'tgchannel':_0x26f0('1'),'feedback':_0x26f0('2'),'status':0x0,'environment':_0x26f0('3'),'receipt':{'receipt_type':_0x26f0('3'),'adam_id':0x3b9aca00,'app_item_id':0x3b9aca00,'bundle_id':_0x26f0('4'),'application_version':_0x26f0('5'),'download_id':0x8159b108e38,'version_external_identifier':0x3b9ac9ff,'receipt_creation_date':_0x26f0('6'),'receipt_creation_date_ms':_0x26f0('7'),'receipt_creation_date_pst':_0x26f0('8'),'request_date':_0x26f0('9'),'request_date_ms':_0x26f0('a'),'request_date_pst':_0x26f0('b'),'original_purchase_date':_0x26f0('9'),'original_purchase_date_ms':_0x26f0('a'),'original_purchase_date_pst':_0x26f0('b'),'original_application_version':_0x26f0('c'),'in_app':[{'quantity':'\x31','product_id':_0x26f0('d'),'transaction_id':_0x26f0('e'),'original_transaction_id':_0x26f0('e'),'purchase_date':_0x26f0('f'),'purchase_date_ms':_0x26f0('a'),'purchase_date_pst':_0x26f0('b'),'original_purchase_date':_0x26f0('9'),'original_purchase_date_ms':_0x26f0('a'),'original_purchase_date_pst':_0x26f0('b'),'expires_date':_0x26f0('6'),'expires_date_ms':_0x26f0('7'),'expires_date_pst':_0x26f0('8'),'web_order_line_item_id':_0x26f0('e'),'is_trial_period':_0x26f0('10'),'is_in_intro_offer_period':_0x26f0('11')}]},'latest_receipt_info':[{'quantity':'\x31','product_id':_0x26f0('d'),'transaction_id':_0x26f0('e'),'original_transaction_id':_0x26f0('e'),'purchase_date':_0x26f0('9'),'purchase_date_ms':_0x26f0('a'),'purchase_date_pst':_0x26f0('b'),'original_purchase_date':_0x26f0('9'),'original_purchase_date_ms':_0x26f0('a'),'original_purchase_date_pst':_0x26f0('b'),'expires_date':_0x26f0('6'),'expires_date_ms':_0x26f0('7'),'expires_date_pst':_0x26f0('8'),'web_order_line_item_id':_0x26f0('e'),'is_trial_period':_0x26f0('10'),'is_in_intro_offer_period':_0x26f0('11'),'subscription_group_identifier':_0x26f0('12')}],'latest_receipt':_0x26f0('1'),'pending_renewal_info':[{'auto_renew_product_id':_0x26f0('d'),'original_transaction_id':_0x26f0('e'),'product_id':_0x26f0('d'),'auto_renew_status':'\x31'}]};$done({'\x62\x6f\x64\x79':JSON[_0x26f0('13')](ddgksf2013)});;_0xody='jsjiami.com.v6';
